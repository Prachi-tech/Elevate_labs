##  Task 3: Linear Regression
##  Objective: Implement and understand simple & multiple linear regression. 


```python
# import libraries

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error,r2_score
from sklearn.preprocessing import LabelEncoder


df= pd.read_csv('C:\\Users\\prach\\Downloads\\Housing.csv')

```


```python

df.head(10)

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
      <th>area</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>stories</th>
      <th>mainroad</th>
      <th>guestroom</th>
      <th>basement</th>
      <th>hotwaterheating</th>
      <th>airconditioning</th>
      <th>parking</th>
      <th>prefarea</th>
      <th>furnishingstatus</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>13300000</td>
      <td>7420</td>
      <td>4</td>
      <td>2</td>
      <td>3</td>
      <td>yes</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>2</td>
      <td>yes</td>
      <td>furnished</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12250000</td>
      <td>8960</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>yes</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>3</td>
      <td>no</td>
      <td>furnished</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12250000</td>
      <td>9960</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>yes</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>no</td>
      <td>2</td>
      <td>yes</td>
      <td>semi-furnished</td>
    </tr>
    <tr>
      <th>3</th>
      <td>12215000</td>
      <td>7500</td>
      <td>4</td>
      <td>2</td>
      <td>2</td>
      <td>yes</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>yes</td>
      <td>3</td>
      <td>yes</td>
      <td>furnished</td>
    </tr>
    <tr>
      <th>4</th>
      <td>11410000</td>
      <td>7420</td>
      <td>4</td>
      <td>1</td>
      <td>2</td>
      <td>yes</td>
      <td>yes</td>
      <td>yes</td>
      <td>no</td>
      <td>yes</td>
      <td>2</td>
      <td>no</td>
      <td>furnished</td>
    </tr>
    <tr>
      <th>5</th>
      <td>10850000</td>
      <td>7500</td>
      <td>3</td>
      <td>3</td>
      <td>1</td>
      <td>yes</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>yes</td>
      <td>2</td>
      <td>yes</td>
      <td>semi-furnished</td>
    </tr>
    <tr>
      <th>6</th>
      <td>10150000</td>
      <td>8580</td>
      <td>4</td>
      <td>3</td>
      <td>4</td>
      <td>yes</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>2</td>
      <td>yes</td>
      <td>semi-furnished</td>
    </tr>
    <tr>
      <th>7</th>
      <td>10150000</td>
      <td>16200</td>
      <td>5</td>
      <td>3</td>
      <td>2</td>
      <td>yes</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>0</td>
      <td>no</td>
      <td>unfurnished</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9870000</td>
      <td>8100</td>
      <td>4</td>
      <td>1</td>
      <td>2</td>
      <td>yes</td>
      <td>yes</td>
      <td>yes</td>
      <td>no</td>
      <td>yes</td>
      <td>2</td>
      <td>yes</td>
      <td>furnished</td>
    </tr>
    <tr>
      <th>9</th>
      <td>9800000</td>
      <td>5750</td>
      <td>3</td>
      <td>2</td>
      <td>4</td>
      <td>yes</td>
      <td>yes</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>1</td>
      <td>yes</td>
      <td>unfurnished</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Encode categorial columns
# converinting 'yes' and 'no' into '0' and '1'

cat_cols = ['mainroad',	'guestroom',	'basement',	'hotwaterheating',	'airconditioning', 'prefarea',	'furnishingstatus']
le = LabelEncoder()

for cols in cat_cols:
    df[cols] = le.fit_transform(df[cols])

#OneHotEncode 'Furnishing status' 
df = pd.get_dummies(df, columns=[ 'furnishingstatus'], drop_first= True)

# check for missing values 
print(df.isnull().sum())
df.dropna(inplace = True)  # drop  rows with missing values if any \

```

    price                 0
    area                  0
    bedrooms              0
    bathrooms             0
    stories               0
    mainroad              0
    guestroom             0
    basement              0
    hotwaterheating       0
    airconditioning       0
    parking               0
    prefarea              0
    furnishingstatus_1    0
    furnishingstatus_2    0
    dtype: int64
    


```python
# means there are no values missing in any of the column 
```


```python
# feature selection and Train-Test split 
X = df.drop(columns=['price'])   #  all features except target 
Y = df['price']                 # Target variable 

X_train, X_test,  Y_train, Y_test = train_test_split(X,Y, test_size=0.2, random_state = 42) 

```


```python
# train the  Linearregression model 

model = LinearRegression()
model.fit(X_train,Y_train)

#predictions
Y_pred = model.predict(X_test)

#asking the model:
# fromabove line , we are asking that
#Based on what you've learned from X_train and y_train, what are the predicted values for X_test?”
```


```python
# evalute the model 

print("Model Evaluation: ")
print("Mean absolute error (MAE):", mean_absolute_error(Y_test,Y_pred))  # MAE: closer to 0 , much better 
print("Mean squared Error(MSE): ", mean_squared_error(Y_test,Y_pred))  # MSE: othe lower is better 
print("R^2 score: ",r2_score(Y_test,Y_pred)) # ranges from 0 to 1, closer to 1 is better , can be -ve if model is very bad 

# MAE: averge of absolute differnce between predicted and actual values 
# MSE: average of squared differnces (penalizes larger errors more than MAE). 
# R^2 : (coefficient of determination )  measures hoe well the model explains the variability of the output

```

    Model Evaluation: 
    Mean absolute error (MAE): 970043.4039201637
    Mean squared Error(MSE):  1754318687330.6628
    R^2 score:  0.6529242642153186
    


```python
#  plot actual vs prideicted prices 

plt.figure(figsize = (8,5))
plt.scatter(Y_test, Y_pred, color='blue')
plt.plot([Y.min(),Y.max()], [Y.min(), Y.max()], 'r--', lw = 2)   # draw a red dash refernce line  representing y = x (i.e perfect preditions)
 # r -- mean color and style  ( dash line , lw = 2 set line width thicker line for betetr )
plt.xlabel('Actual Price')
plt.ylabel('Predicted Prices')
plt.title('Actual vs Predicted prices')
plt.grid(True)  # add grid lines make it eaiser to interpret the data points
plt.show()

# these dots close to straight line that means good predictions
```


    
![png](output_8_0.png)
    



```python
# coefficicent Interpretation 

coefficients = pd.DataFrame({
    'Feature':X.columns,
    'Coefficient': model.coef_
})

print(coefficients)
```

                   Feature   Coefficient
    0                 area  2.359688e+02
    1             bedrooms  7.677870e+04
    2            bathrooms  1.094445e+06
    3              stories  4.074766e+05
    4             mainroad  3.679199e+05
    5            guestroom  2.316100e+05
    6             basement  3.902512e+05
    7      hotwaterheating  6.846499e+05
    8      airconditioning  7.914267e+05
    9              parking  2.248419e+05
    10            prefarea  6.298906e+05
    11  furnishingstatus_1 -1.268818e+05
    12  furnishingstatus_2 -4.136451e+05
    

 ## Conclusion 
 
 * Applied simple and multiple linear regression using the housing prices predictiondataset.
 * Used Scikit-learn for model building and evaluation.
 * handled categorial variables using Label Encoding  and One-Hot Encoding.
 * Trained the model and evaluated it using MAE,MSE, R^2 score.
 * Interpreted regression coefficients to understand the effect of each feature.
 * Gained practical understanding of regression modeling and evaluation techniques. 



```python

```
